function score = Mean_IGD(Population,Problem)
% <min> <multi/many> <real/integer/label/binary/permutation> <large/none> <constrained/none> <expensive/none> <multimodal/none> <sparse/none> <dynamic/none> <robust>
% Mean inverted generational distance (for robust optimization)

%------------------------------- Reference --------------------------------
% C. A. Coello Coello and N. C. Cortes. Solving multiobjective optimization
% problems using an artificial immune system. Genetic Programming and
% Evolvable Machines, 2005, 6(2): 163-190.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2025 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

% 测试我自己的问题
disp("----------------DRLAOS-ROO------------------------------")
% DRLAOS-ROO
x1 = [6.7, 98, 22.7, -49.3, 19, 5.85]; % DRLAOS-ROO
PopX1 = Problem.PerturbMeanIGD(x1); % 1 * 5000 double
Pop1Obj = PopX1.objs;
Pop1ObjMeans = mean(Pop1Obj, 1);
mean_Pop1ObjMeans = mean(Pop1ObjMeans);
disp(Pop1ObjMeans);
disp(mean_Pop1ObjMeans);
save('DRLAOS-ROO_results.mat', 'Pop1Obj', 'Pop1ObjMeans', 'mean_Pop1ObjMeans');

disp("----------------MOEA-RE------------------------------")
% MOEA-RE
x2 = [6.7, 98, 22.7, -49.301, 19, 5.85]; % MOEA-RE
PopX2 = Problem.PerturbMeanIGD(x2); 
Pop2Obj = PopX2.objs;
Pop2ObjMeans = mean(Pop2Obj, 1);
mean_Pop2ObjMeans = mean(Pop2ObjMeans);
disp(Pop2ObjMeans);
disp(mean_Pop2ObjMeans);
save('MOEA-RE_results.mat', 'Pop2Obj', 'Pop2ObjMeans', 'mean_Pop2ObjMeans');

disp("----------------RMOEA-DVA------------------------------")
% RMOEA-DVA
x3 = [7.9832, 93.2449, 16.6767, -52.3102, 17.4953, 6.288]; % MOEA-RE
PopX3 = Problem.PerturbMeanIGD(x3); 
Pop3Obj = PopX3.objs;
Pop3ObjMeans = mean(Pop3Obj, 1);
mean_Pop3ObjMeans = mean(Pop3ObjMeans);
disp(Pop3ObjMeans);
disp(mean_Pop3ObjMeans);
save('RMOEA-DVA_results.mat', 'Pop3Obj', 'Pop3ObjMeans', 'mean_Pop3ObjMeans');




N     = length(Population); % 获得种群大小，算法得到的解集中的解的个数。
% 对种群进行扰动。
PopX  = Problem.PerturbMeanIGD(Population.decs); % 1 * 5000 double
% PopXobjs = PopX.objs;
score = []; % 初始化一个空数组，用于存储每次扰动后计算的IGD值。

for i = 1:N
    % 获取围绕第 i 个解采样的 50 个点
    sampled_points = PopX(:,(i-1)*Problem.H + 1 : i*Problem.H);
    PopObj = sampled_points.best.objs;
    % 检查当前解的目标函数维度是否与真实Pareto前沿Problem.optimum维度一致。
    if size(PopObj,2) ~= size(Problem.optimum,2)
        score = [score,nan];
    else
        % 如果维度一致，计算当前批次的IGD 
        score = [score,mean(min(pdist2(Problem.optimum,PopObj),[],2))];
    end
end


% 计算所有有效的IGD值的平均值，忽略NaN值。
% ~isnan(score) 返回一个逻辑数组，标记 score 中非 NaN 的值
score = mean(score(~isnan(score)));
end
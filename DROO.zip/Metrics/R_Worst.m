function score = R_Worst(Population,Problem)
% <min> <multi/many> <real/integer/label/binary/permutation> <large/none> <constrained/none> <expensive/none> <multimodal/none> <sparse/none> <dynamic/none> <robust>
% Mean minimum euclidean distance (for robust optimization)

%------------------------------- Reference --------------------------------
% C. A. Coello Coello and N. C. Cortes. Solving multiobjective optimization
% problems using an artificial immune system. Genetic Programming and
% Evolvable Machines, 2005, 6(2): 163-190.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2025 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

bestInd = Population.bestPop; % 当前种群中最好的解的索引 31 * 1 double
bestPops = Population(:,bestInd);
% 获取解集的大小
N = size(bestInd,1);

% 对决策变量进行扰动，生成 PopX（(N*50) * 10）
PopX = Problem.PerturbRMetric(bestPops.decs);
PopXobjs = PopX.objs;

% 初始化存储每个解的平均最小欧几里得距离
d_mean = zeros(N, 1);

% 遍历每个解
for i = 1:N
    % 获取围绕第 i 个解采样的 50 个点
    sampled_points = PopXobjs((i-1)*Problem.H + 1 : i*Problem.H, :); 
    % 计算每个采样点到真实 Pareto 前沿的最小欧几里得距离
    dist = min(pdist2(sampled_points, Problem.optimum), [], 2); 
    % 计算第 i 个解的最差最小欧几里得距离
    d_mean(i) = max(dist);
end

% 计算整个解集的 R_mean
score = mean(d_mean);
end
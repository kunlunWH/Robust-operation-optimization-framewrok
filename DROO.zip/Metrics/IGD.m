function score = IGD(Population,optimum)
% <min> <multi/many> <real/integer/label/binary/permutation> <large/none> <constrained/none> <expensive/none> <multimodal/none> <sparse/none> <dynamic/none> <robust/none>
% Inverted generational distance

%------------------------------- Reference --------------------------------
% C. A. Coello Coello and N. C. Cortes. Solving multiobjective optimization
% problems using an artificial immune system. Genetic Programming and
% Evolvable Machines, 2005, 6(2): 163-190.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2025 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    PopObj = Population.best.objs; % 27x2 double
    if size(PopObj,2) ~= size(optimum,2) % optimum 10000x2 double
        score = nan;
    else
        % pdist2(optimum, PopObj):计算真实 Pareto 前沿 optimum 和算法解集 PopObj
        %   之间的距离矩阵。
        % 假设 optimum 有 m 个点，PopObj 有 n 个点，则距离矩阵的大小为 m x n，其
        %   中每个元素表示 optimum 中一个点到 PopObj 中一个点的距离。
        % min(pdist2(optimum, PopObj), [], 2)：对每个真实 Pareto 前沿点，找到算法解集
        % 中最近的点，并返回这些最小距离。“2”对每一行，沿着列走。
        score = mean(min(pdist2(optimum,PopObj),[],2));
    end
end
function score = Upsilon(Population,optimum)
% <min> <multi/many> <real/integer/label/binary/permutation> <large/none> <constrained/none> <expensive/none> <multimodal/none> <sparse/none> <dynamic/none> <robust/none>
% Y 衡量的是算法解集 S 中每个解到真实 Pareto 前沿 P 的最小欧几里得距离的平均值。

%------------------------------- Reference --------------------------------
% C. A. Coello Coello and N. C. Cortes. Solving multiobjective optimization
% problems using an artificial immune system. Genetic Programming and
% Evolvable Machines, 2005, 6(2): 163-190.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2025 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

PopObj = Population.best.objs; % 27x2 double
if size(PopObj,2) ~= size(optimum,2) % optimum 10000x2 double
    score = nan;
else
    % % 计算算法解集中每个解到真实 Pareto 前沿的最小距离
    minDist = min(pdist2(PopObj, optimum), [], 2);
    % Υ 指标为最小距离的平均值
    score = mean(minDist);
end
end
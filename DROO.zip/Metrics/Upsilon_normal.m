function score = Upsilon_normal(Population,optimum)
% <min> <multi/many> <real/integer/label/binary/permutation> <large/none> <constrained/none> <expensive/none> <multimodal/none> <sparse/none> <dynamic/none> <robust/none>
% Y 衡量的是算法解集 S 中每个解到真实 Pareto 前沿 P 的最小欧几里得距离的平均值。

%------------------------------- Reference --------------------------------
% C. A. Coello Coello and N. C. Cortes. Solving multiobjective optimization
% problems using an artificial immune system. Genetic Programming and
% Evolvable Machines, 2005, 6(2): 163-190.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2025 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

PopObj = Population.best.objs; % 27x2 double
if size(PopObj,2) ~= size(optimum,2) % optimum 10000x2 double
    score = nan;
else
    % 归一化处理
    % 合并种群解和Pareto前沿解以计算归一化参数
    allObjs = [PopObj; optimum];
    
    % 计算每一维目标的最小值和范围
    minVals = min(allObjs, [], 1);
    maxVals = max(allObjs, [], 1);
    ranges = maxVals - minVals;
    
    % 避免除以零（如果某维所有值相同）
    ranges(ranges == 0) = 1;
    
    % 归一化种群解和Pareto前沿解
    normPopObj = (PopObj - minVals) ./ ranges;
    normOptimum = (optimum - minVals) ./ ranges;
    
    % 计算算法解集中每个解到真实 Pareto 前沿的最小距离
    minDist = min(pdist2(normPopObj, normOptimum), [], 2);
    
    % Υ 指标为最小距离的平均值
    score = mean(minDist);
end
end
function score = Mean_IGD_normal(Population,Problem)
% <min> <multi/many> <real/integer/label/binary/permutation> <large/none> <constrained/none> <expensive/none> <multimodal/none> <sparse/none> <dynamic/none> <robust>
% Mean inverted generational distance (for robust optimization)

%------------------------------- Reference --------------------------------
% C. A. Coello Coello and N. C. Cortes. Solving multiobjective optimization
% problems using an artificial immune system. Genetic Programming and
% Evolvable Machines, 2005, 6(2): 163-190.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2025 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

% N = length(Population); % 获得种群大小，算法得到的解集中的解的个数。
%% 进行归一化时，目标在扰动情况下的变化值。
disp("---------------- CNSDE-DVC------------------------------")
% N = length(Population);
x1 = [4.4662, 1.0065, 1.0346, 5.8899, 1.0141, 1.0222]; % CNSDE-DVC
PopX1 = Problem.PerturbMeanIGD(x1); % 1 * 5000 double

% score = []; % 初始化一个空数组，用于存储每次扰动后计算的IGD值。

% ===== 归一化处理（移到 for 循环外）=====
% 获取所有 PopX 的目标函数值（假设 PopX 是一个结构体数组，需要提取 objs）
% allPop1Objs = [PopX1.objs]; % 假设 PopX 有 objs 属性
% allObjs = [allPopObjs; Problem.optimum]; % 合并当前解和Pareto前沿解

% 计算每一维目标的最小值和范围
% minVals1 = min(allPop1Objs, [], 1);
% maxVals1 = max(allPop1Objs, [], 1);
% ranges1 = maxVals1 - minVals1;

% 避免除以零（如果某维所有值相同）
% ranges1(ranges1 == 0) = 1;
% normPop1Obj = (PopX1.objs - minVals1) ./ ranges1;
% normPop1ObjMeans = mean(normPop1Obj, 1);
% mean_normPop1ObjMeans = mean(normPop1ObjMeans);
% disp(normPop1ObjMeans);
% disp(mean_normPop1ObjMeans);

normPop1Obj = PopX1.objs;
normPop1ObjMeans = mean(normPop1Obj, 1);
mean_normPop1ObjMeans = mean(normPop1ObjMeans);
disp(normPop1ObjMeans);
disp(mean_normPop1ObjMeans);
save('CNSDE_DVC_normalized_results.mat', 'normPop1Obj', 'normPop1ObjMeans', 'mean_normPop1ObjMeans');

disp("---------------- CPRO------------------------------")
x2 = [4.5, 1, 1, 6, 1, 1]; % CPRO
PopX2 = Problem.PerturbMeanIGD(x2); % 1 * 5000 double

allPop2Objs = [PopX2.objs]; % 假设 PopX 有 objs 属性
% allObjs = [allPopObjs; Problem.optimum]; % 合并当前解和Pareto前沿解

% 计算每一维目标的最小值和范围
% minVals2 = min(allPop2Objs, [], 1);
% maxVals2 = max(allPop2Objs, [], 1);
% ranges2 = maxVals2 - minVals2;

% 避免除以零（如果某维所有值相同）
% ranges2(ranges2 == 0) = 1;

% normPop2Obj = (PopX2.objs - minVals2) ./ ranges2;
% normPop2ObjMeans = mean(normPop2Obj, 1);
% mean_normPop2ObjMeans = mean(normPop2ObjMeans);
% disp(normPop2ObjMeans);
% disp(mean_normPop2ObjMeans);

% Save the variables to a .mat file
normPop2Obj = PopX2.objs;
normPop2ObjMeans = mean(normPop2Obj, 1);
mean_normPop2ObjMeans = mean(normPop2ObjMeans);
disp(normPop2ObjMeans);
disp(mean_normPop2ObjMeans);
save('CPRO_normalized_results.mat', 'normPop2Obj', 'normPop2ObjMeans', 'mean_normPop2ObjMeans');

disp("---------------- RMOEA-DVA ------------------------------")
x3 = [4.4074,1.4068,1.1876,5.6502,1.0835,1.0897]; % RMOEA-DVA
PopX3 = Problem.PerturbMeanIGD(x3); % 1 * 5000 double
% allPop3Objs = [PopX3.objs]; % 假设 PopX 有 objs 属性
% minVals3 = min(allPop3Objs, [], 1);
% maxVals3 = max(allPop3Objs, [], 1);
% ranges3 = maxVals3 - minVals3;

% 避免除以零（如果某维所有值相同）
% ranges3(ranges3 == 0) = 1;

% normPop3Obj = (PopX3.objs - minVals3) ./ ranges3;

normPop3Obj = PopX3.objs;
normPop3ObjMeans = mean(normPop3Obj, 1);
mean_normPop3ObjMeans = mean(normPop3ObjMeans);
disp(normPop3ObjMeans);
disp(mean_normPop3ObjMeans);

save('RMOEA_DVA_normalized_results.mat', 'normPop3Obj', 'normPop3ObjMeans', 'mean_normPop3ObjMeans');

%% 不进行归一化时，目标在扰动情况下的变化值。
% disp("----------------CNSDE-DVC、CPRO------------------------------")
% Pop1ObjMeans = mean(allPop1Objs, 1); % CNSDE-DVC
% disp(Pop1ObjMeans);
% disp(mean(normPop1ObjMeans));
% 
% Pop2ObjMeans = mean(allPop2Objs, 1); % CPRO
% disp(Pop2ObjMeans);
% disp(mean(normPop2ObjMeans));

%% 不进行归一化时，目标在扰动情况下的变化值。 RMOEA-DVA
% disp("-----------------CNSDE-DVC-----------------------------")
% % x3 = [4.4074,1.4068,1.1876,5.6502,1.0835,1.0897];
% % PopX3 = Problem.PerturbMeanIGD(x3); % 1 * 5000 double
% Pop3ObjMeans = mean(PopX3.objs, 1); % CNSDE-DVC
% disp(Pop3ObjMeans);
% disp(mean(Pop3ObjMeans));

% 归一化 PopX 和 Problem.optimum
% normPopX = (allPopObjs - minVals) ./ ranges;
% normPopX = (allPopObjs - minVals) ./ ranges;
% normOptimum = (Problem.optimum - minVals) ./ ranges;

% N = length(Population); % 获得种群大小，算法得到的解集中的解的个数。
% PopX = Problem.PerturbMeanIGD(Population.decs); % 1 * 5000 double
% score = []; % 初始化一个空数组，用于存储每次扰动后计算的IGD值。



for i = 1:N
    % 获取围绕第 i 个解采样的 50 个点
    sampled_points = PopX(:,(i-1)*Problem.H + 1 : i*Problem.H);
    PopObj = sampled_points.best.objs;
    
    % 检查当前解的目标函数维度是否与真实Pareto前沿Problem.optimum维度一致。
    if size(PopObj,2) ~= size(Problem.optimum,2)
        score = [score, nan];
    else
        % ===== 归一化处理 =====
        %         % 合并当前解和Pareto前沿解以计算归一化参数
        %         allObjs = [PopObj; Problem.optimum];
        
        %         % 计算每一维目标的最小值和范围
        %         minVals = min(allObjs, [], 1);
        %         maxVals = max(allObjs, [], 1);
        %         ranges = maxVals - minVals;
        %
        %         % 避免除以零（如果某维所有值相同）
        %         ranges(ranges == 0) = 1;
        
        % 归一化当前解和Pareto前沿解
        normPopObj = (PopObj - minVals) ./ ranges;
        normOptimum = (Problem.optimum - minVals) ./ ranges;
        
        % 计算归一化后的IGD
        distMatrix = pdist2(normOptimum, normPopObj); % 计算Pareto前沿到当前解的距离
        minDist = min(distMatrix, [], 2); % 每个Pareto前沿点到当前解的最小距离
        currentIGD = mean(minDist); % 计算IGD
        
        score = [score, currentIGD];
    end
end

% 计算所有有效的IGD值的平均值，忽略NaN值。
score = mean(score(~isnan(score)));
end
function score = Mean_HV(Population,Problem)
% <max> <multi/many> <real/integer/label/binary/permutation> <large/none> <constrained/none> <expensive/none> <multimodal/none> <sparse/none> <dynamic/none> <robust>
% Mean hypervolume (for robust optimization)

%------------------------------- Reference --------------------------------
% C. A. Coello Coello and N. C. Cortes. Solving multiobjective optimization
% problems using an artificial immune system. Genetic Programming and
% Evolvable Machines, 2005, 6(2): 163-190.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2025 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    N     = length(Population);
    PopX  = Problem.Perturb(Population.decs);
    % 先暂时不采用我的计算算法。
    % PopX  = Problem.PerturbMeanIGD(Population.decs); % 1 * 5000 double
    score = [];
    for i = 1 : N : length(PopX)
        score = [score,HV(PopX(i:i+N-1),Problem.optimum)];
    end
    score = mean(score(~isnan(score)));
end
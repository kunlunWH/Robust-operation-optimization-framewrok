% ================================================
% run_mgsr_multiple_fixed.m
% 说明：执行 GPTIPS 训练多次（如 10 次），并保存每次的反归一化表达式、训练时间、R²、RMSE。
% 修复：避免在反归一化时向表达式中传入整列数据，改为逐样本计算，以消除维度不匹配错误。
% ================================================

% —————— 1. 清理环境并定位路径 ——————
close all; clear; clc;
scriptDir = fileparts(mfilename('fullpath'));

% —————— 2. 初始化结果表格和表达式目录 ——————
numRuns = 20;  % 设定重复运行次数
results = table('Size', [0,8], ...
    'VariableTypes', {'double','string','double','double','double','double','double','string'}, ...
    'VariableNames', {'Run','Dataset','TrainTime_sec','R2','RMSE','Complexity','NumTrainSamples','ExprFilename'});

output_expr_dir = fullfile(scriptDir,'resource','saved_models','gptips','expressions');
if ~exist(output_expr_dir, 'dir')
    mkdir(output_expr_dir);
end

% —————— 3. 选择并加载数据集 ——————
dataset = "mydata_Energy";
matfile = fullfile(scriptDir, 'resource', dataset + ".mat");
load(matfile);  % 变量应包含：xtrain, ytrain, xtest, ytest

% 合并原始数据
X_raw_all = [xtrain; xtest];
y_raw_all = [ytrain'; ytest'];

% 预先记录“原始训练集大小”，在循环里不再读取 xtrain
original_train_count = size(xtrain, 1);

% —————— 4. 循环执行多次训练 ——————
for runIdx = 1:numRuns
    fprintf('=== Run %d/%d ===\n', runIdx, numRuns);

    % —— 4.1 手动划分（不打乱）——
    num_train = original_train_count + 75;
    X_train = X_raw_all(1:num_train, :);
    X_test  = X_raw_all(num_train+1:end, :);
    y_train = y_raw_all(1:num_train);
    y_test  = y_raw_all(num_train+1:end);

    % —— 4.2 归一化（使用训练集统计量）——
    min_X = min(X_train, [], 1);
    max_X = max(X_train, [], 1);
    range_X = max_X - min_X;
    range_X(range_X == 0) = 1;

    min_y = min(y_train);
    max_y = max(y_train);
    range_y = max_y - min_y;
    if range_y == 0
        range_y = 1;
    end

    xtrain_n = (X_train - min_X) ./ range_X;
    ytrain_n = (y_train - min_y) ./ range_y;
    xtest_n  = (X_test  - min_X) ./ range_X;
    ytest_n  = (y_test  - min_y) ./ range_y;

    % —— 4.3 注入 GPTIPS 所需变量到 base workspace ——————
    assignin('base', 'xtrain', xtrain_n);
    assignin('base', 'ytrain', ytrain_n);
    assignin('base', 'xtest',  xtest_n);
    assignin('base', 'ytest',  ytest_n);

    assignin('base', 'min_X',   min_X);
    assignin('base', 'range_X', range_X);
    assignin('base', 'min_y',   min_y);
    assignin('base', 'range_y', range_y);

    % —— 4.4 调用 GPTIPS 并记录时间 ——————
    tic;
    gp = rungp(@my_config_mgsr_v2, dataset + "_causal_path.mat");
    train_time = toc;

    % —— 4.5 获取最佳表达式及复杂度 ——————
    best_expr_str = gppretty(gp, 'best');               % 归一化输入下的表达式
    complexity = gp.results.best.complexity;             % 模型复杂度

    % —— 4.6 生成可用于逐样本计算的归一化表达式模板 ——————
    expr_scaled_template = char(best_expr_str);
    d = size(xtrain, 2);
    for i = 1:d
        % 将 x_i 替换为 '( (X_test_sample(i) - min_X(i)) / range_X(i) )'
        old_var_pattern = sprintf('\\<x%d\\>', i);
        % 暂时用占位符 'XTS(%d)'，后续循环中再替换为具体值
        replacement = sprintf('XTS(%d)', i);
        expr_scaled_template = regexprep(expr_scaled_template, old_var_pattern, replacement);
    end
    % 将乘法和幂操作转换为逐元素运算，以便于字符串 eval 时计算正确
%     expr_scaled_template = regexprep(expr_scaled_template, '(?<!\.)\*', '.*');
%     expr_scaled_template = regexprep(expr_scaled_template, '(?<!\.)\^', '.^');

    % —— 4.7 逐样本计算反归一化预测值 ——————
    num_test = size(X_test, 1);
    y_pred = zeros(num_test, 1);

    for idx = 1:num_test
        % 1) 构造每个样本的归一化变量值向量 XTS
        XTS = zeros(1, d);
        for j = 1:d
            XTS(j) = ( X_test(idx, j) - min_X(j) ) / range_X(j);
        end

        % 2) 用实际数值替换模板中的 'XTS(j)'
        expr_per_sample = expr_scaled_template;
        for j = 1:d
            % 用数值常量替换占位符 XTS(j)
            num_str = sprintf('(%g)', XTS(j));
            expr_per_sample = regexprep(expr_per_sample, sprintf('XTS\\(%d\\)', j), num_str);
        end

        % 3) 计算归一化输出，并反归一化到原始尺度
        %    expr_per_sample 相当于一个仅含数字常量和运算符的完整表达式
        y_norm_val = eval(expr_per_sample);  % 归一化预测值
        y_pred(idx) = range_y * y_norm_val + min_y;
    end

    % —— 4.8 计算 R² 与 RMSE ——————
    ytest_real = y_test(:);
    y_pred_real = y_pred(:);
    R2 = 1 - sum((ytest_real - y_pred_real).^2) / sum((ytest_real - mean(ytest_real)).^2);
    RMSE = sqrt(mean((ytest_real - y_pred_real).^2));

    % —— 4.9 保存反归一化表达式到单独文本文件 ——————
    % 将最终可用的标量化表达式保存为文本（带占位符的模板）
    % 注意：此处保存的是 expr_original_template，可用于审核；实际预测使用逐样本 eval。
    expr_original_template = sprintf('y_pred = %g * ( %s ) + %g;', ...
        range_y, expr_scaled_template, min_y);

    exprFilename = sprintf('%s_expr_run%02d.txt', dataset, runIdx);
    fullExprPath = fullfile(output_expr_dir, exprFilename);
    fid = fopen(fullExprPath, 'w');
    fprintf(fid, '%s\n', expr_original_template);
    fclose(fid);

    % —— 4.10 将当前运行结果追加到结果表 ——————
    results(end+1, :) = { ...
        runIdx, dataset, train_time, R2, RMSE, complexity, num_train, exprFilename ...
    };

    fprintf('Run %d: TrainTime=%.4f s, R2=%.4f, RMSE=%.4f, Complexity=%d, NumTrain=%d\n', ...
        runIdx, train_time, R2, RMSE, complexity, num_train);
end

% —————— 5. 将所有运行结果保存至 CSV 文件 ——————
resultsFilename = sprintf('%s_results_summary.csv', dataset);
fullResultsPath = fullfile(output_expr_dir, resultsFilename);
writetable(results, fullResultsPath);

fprintf('所有运行完成，结果已保存至：\n  %s\n  %s\n', ...
    fullResultsPath, output_expr_dir);

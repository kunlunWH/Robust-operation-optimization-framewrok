function gp = my_config_mgsr_v2(gp)
% 配置 GPTIPS 多基因符号回归

% 基本运行控制
gp.runcontrol.pop_size = 1000; % 1000
gp.runcontrol.num_gen = 500; % 500
gp.runcontrol.verbose = 1;

% 适应度函数（多基因拟合）
gp.fitness.fitfun = @regressmulti_fitfun;
gp.fitness.minimisation = true;

% 加载数据（推荐用 assignin 提前注入 base workspace 中的变量）
if evalin('base', 'exist(''xtrain'', ''var'')') && ...
   evalin('base', 'exist(''ytrain'', ''var'')') && ...
   evalin('base', 'exist(''xtest'', ''var'')') && ...
   evalin('base', 'exist(''ytest'', ''var'')')
   
    gp.userdata.xtrain = evalin('base', 'xtrain');
    gp.userdata.ytrain = evalin('base', 'ytrain');
    gp.userdata.xtest = evalin('base', 'xtest');
    gp.userdata.ytest = evalin('base', 'ytest');
else
    error('Training/testing data (xtrain, ytrain, etc.) not found in base workspace.');
end

% 输入维度
gp.nodes.inputs.num_inp = size(gp.userdata.xtrain, 2);

% 启用多基因 GP
gp.genes.multigene = true;
gp.genes.max_genes = 2;

% 树结构参数
gp.treedef.max_depth = 10;  % 10 8 6 4

% 运算符集合（函数节点）
% gp.nodes.functions.name = {'plus', 'minus', 'times'};
gp.nodes.functions.name = {'plus', 'minus', 'times', 'rdivide', 'exp', 'log', 'sin', 'cos'};

% gp.nodes.const.use_consts = true;
% gp.nodes.const.min_const = -10;
% gp.nodes.const.max_const = 10;

% 复杂度度量方式，false 表示用节点数计数
gp.fitness.complexityMeasure = false;

% 最大节点数，30个
gp.treedef.max_nodes = 30;

end
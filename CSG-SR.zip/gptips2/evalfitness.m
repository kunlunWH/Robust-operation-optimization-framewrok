function gp = evalfitness(gp)
%EVALFITNESS Calls the user specified fitness function.
%
%   GP = EVALFITNESS(GP) evaluates the the fitnesses of individuals stored
%   in the GP structure and updates various other fields of GP accordingly.
%
%   Copyright (c) 2009-2015 Dominic Searson
%
%   GPTIPS 2
%
%   See also TREE2EVALSTR, EVALFITNESS_PAR

%check parallel mode.
if gp.runcontrol.parallel.enable && gp.runcontrol.parallel.ok
    gp = evalfitness_par(gp);
    return;
    
    %regular version
else
    
    for i = 1:gp.runcontrol.pop_size % 1- 100
        
        gp.state.current_individual = i; % 1
        
        %retrieve values if cached
        if gp.runcontrol.usecache && gp.fitness.cache.isKey(i) % isKey(i)：检查某个键是否存在于缓存中
            cache = gp.fitness.cache(i);
            gp.fitness.complexity(i,1) = cache.complexity;
            gp.fitness.values(i,1) = cache.value;
            gp.fitness.returnvalues{i,1} = cache.returnvalues;
            
        else
            %preprocess cell array of string expressions into a form that
            %Matlab can evaluate
            evalstr = tree2evalstr(gp.pop{i},gp); % {'exp(times(exp(x4),[5.0485]))'}，复杂度为5
            
            %store complexity of individual (either number of nodes or tree
            %expressional complexity)
            if gp.fitness.complexityMeasure
                gp.fitness.complexity(i,1) = getcomplexity(gp.pop{i});
            else
                gp.fitness.complexity(i,1) = getnumnodes(gp.pop{i});
            end
            
            % 调用一个由用户指定的适应度函数（fitness function）来评估个体表达式的适应度，
            % 并返回适应度值和更新后的 gp 结构体。
            [fitness,gp] = feval(gp.fitness.fitfun,evalstr,gp); % fitness：0.99，
            gp.fitness.values(i) = fitness; % 将regressmulti_fitfun中返回的fitness=Inf放进去。
            
        end
    end
end
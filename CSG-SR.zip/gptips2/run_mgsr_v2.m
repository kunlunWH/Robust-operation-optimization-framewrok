% —————— 开头：清理环境并定位路径 ——————
close all; clear all; clc;
scriptDir = fileparts(mfilename('fullpath'));

% —————— 初始化结果表 ——————
results = table('Size', [0,5], ...
    'VariableTypes', {'string','double','double','double','string'}, ...
    'VariableNames', {'dataset','score','train_time_sec','model_complexity','best_expression'});
output_expr_dir = fullfile(scriptDir,'resource','saved_models','gptips','expressions');
if ~exist(output_expr_dir,'dir'), mkdir(output_expr_dir); end

% try
% 清空 Base 工作区中相关变量
evalin('base','clear xtrain ytrain xtest ytest min_X max_X min_y max_y');

dataset = "mydata_Strength";
matfile = fullfile(scriptDir, 'resource', dataset + ".mat");
load(matfile);    % 取出 xtrain, ytrain, xtest, ytest
ytrain = ytrain(:);
ytest  = ytest(:);

%—————— 1. 最值归一化（[0,1] 区间）步骤 ——————
% 1.1 计算训练集每列特征的 min/max
min_X = min(xtrain, [], 1);    % 1×d 向量：每列的最小值
max_X = max(xtrain, [], 1);    % 1×d 向量：每列的最大值
range_X = max_X - min_X;        % 1×d 向量：每列的极差
% 避免极差为 0 的情况
range_X(range_X==0) = 1;

% 1.2 计算训练集目标的 min/max
min_y = min(ytrain);
max_y = max(ytrain);
range_y = max_y - min_y;
if range_y == 0
    range_y = 1;
end

% 1.3 对训练集做最值归一化
xtrain_n = (xtrain - min_X) ./ range_X;   % N×d
ytrain_n = (ytrain - min_y) ./ range_y;   % N×1

% 1.4 对测试集也用相同的 min_X/max_X 做最值归一化
xtest_n = (xtest - min_X) ./ range_X;      % M×d
ytest_n = (ytest - min_y) ./ range_y;      % M×1

% 1.5 将归一化后的数据注入 Base 工作区（供 my_config_mgsr_v2 读取）
assignin('base', 'xtrain', xtrain_n);
assignin('base', 'ytrain', ytrain_n);
assignin('base', 'xtest',  xtest_n);
assignin('base', 'ytest',  ytest_n);

%—————— 2. 运行 GPTIPS ——————
tic;
gp = rungp(@my_config_mgsr_v2, dataset + "_causal_path.mat");
train_time = toc;
best_expr_str = gppretty(gp, 'best');
complexity = num2str(gp.results.best.complexity);

%—————— 3. 构造“原始量纲”表达式 ——————
% 将 min_X, range_X, min_y, range_y 注入到 Base
assignin('base', 'min_X', min_X);
assignin('base', 'range_X', range_X);
assignin('base', 'min_y', min_y);
assignin('base', 'range_y', range_y);

% 假定输入维度 d
d = size(xtrain,2);
%     expr_scaled = best_expr_str;
expr_scaled = char(best_expr_str);
for i = 1 : d
    % 原始 best_expr_str 中的 x{i} 即代表 x_i 经过 [0,1] 归一化后的值
    old_var = sprintf('x%d', i);
    new_var = sprintf('((x(:,%d) - min_X(%d)) / range_X(%d))', i, i, i);
    expr_scaled = strrep(expr_scaled, old_var, new_var);
end
% 最终反归一化：y_pred = range_y * f_scaled(...) + min_y
expr_original = sprintf('y_pred = range_y * (%s) + min_y;', expr_scaled);

%—————— 4. 在测试集上预测并反归一化 ——————
% 确保 workspace 中有 xtest, min_X, range_X, min_y, range_y
eval(expr_original);   % 生成 y_pred（列向量，已恢复到原始量纲）
RMSE = sqrt(mean((ytest - y_pred).^2));
R2   = 1 - sum((ytest - y_pred).^2) / sum((ytest - mean(ytest)).^2);
score = R2;

%—————— 5. 保存表达式文本和记录结果 ——————
expr_file = fullfile(output_expr_dir, dataset + "_best_expr_originalScale.txt");
fid = fopen(expr_file, 'w');
fprintf(fid, '%s\n', expr_original);
fclose(fid);

results = [results; {dataset, score, train_time, str2double(complexity), expr_original}];

% catch ME
%     fprintf('!!! 数据集 %s 处理失败: %s\n', dataset, ME.message);
% end

%—————— 6. 导出 CSV 并绘图 ——————
results_file = fullfile(scriptDir, 'resource', 'gptips_results.csv');
writetable(results, results_file, 'Encoding', 'UTF-8');
disp(['✅ 所有数据集处理完成，结果已保存为 ', results_file]);

figure('Position',[100,100,1200,500]);
subplot(1,2,1);
boxchart(results.score);
title('GPTIPS R^2 Score'); ylabel('R^2 Score');
set(gca,'XTickLabel',{'All Datasets'});

subplot(1,2,2);
boxchart(results.model_complexity);
title('GPTIPS Model Complexity'); ylabel('Expression Length');
set(gca,'XTickLabel',{'All Datasets'});

sgtitle('GPTIPS Performance and Complexity');
drawtrees(gp,'best');  % 浏览器界面可视化表达式树

function gp = gpinit(gp)
%GPINIT Initialises a run.
%
%   GP = GPINIT(GP)
%
%   Copyright (c) 2009-2015 Dominic Searson
%
%   GPTIPS 2
%
%   See also GPCHECK, GPDEFAULTS, GPINITPARALLEL

%determine status of symbolic, parallel and stats toolboxes
[gp.info.toolbox.symbolic, gp.info.toolbox.parallel, gp.info.toolbox.stats] = gptoolboxcheck;

%process function nodes before run
gp = procfuncnodes(gp);

%throw an error if there are no inputs, p_ERC=0 and there are no arity zero
%functions active
if  gp.nodes.inputs.num_inp == 0 && gp.nodes.const.p_ERC == 0 && ...
        isempty(find(gp.nodes.functions.arity(logical(gp.nodes.functions.active)) == 0, 1))
    error('No terminals (inputs, constants or zero arity functions) have been defined for this run.');
end

%initialise some state and tracker variables
gp.state.count = 1;
gp.state.best.fitness = [];
gp.state.best.individual = [];
gp.state.run_completed = false;
gp.state.current_individual = [];
gp.state.std_devfitness = [];
gp.state.terminate = false;
gp.state.force_compute_theta = false;
gp.fitness.returnvalues = cell(gp.runcontrol.pop_size,1);

% process mutation probabilities vector
gp.operators.mutation.cumsum_mutate_par = cumsum(gp.operators.mutation.mutate_par); % 1*6 double [0.9, 0.05, 0.05, 0, 0, 0];

% init. history variables
gp.results.history.bestfitness = zeros(gp.runcontrol.num_gen,1); % 5*1 double
gp.results.history.meanfitness = zeros(gp.runcontrol.num_gen,1);
gp.results.history.std_devfitness = zeros(gp.runcontrol.num_gen,1);
gp.results.history.about = 'Fitness on training data';
% 将结构体 gp.results.history 中的字段按字母顺序重新排序，保持结构字段的一致性和可读性。
gp.results.history = orderfields(gp.results.history);

%best of run (on training data) fields
gp.results.best.fitness = [];
gp.results.best.individual = [];
gp.results.best.returnvalues = [];
gp.results.best.foundatgen = [];
gp.results.best.about = 'Best individual on training data';
gp.results.best = orderfields(gp.results.best);

%assign field holding fitnesses to gp structure
gp.fitness.values = zeros(gp.runcontrol.pop_size,1); % 100x1 double
% 分配用于保存个体“复杂度”的向量。表示表达式复杂度，通常与树的节点数、深度、基因数等有关。
gp.fitness.complexity = zeros(gp.runcontrol.pop_size,1); % 100x1 double

% 判断当前设置的适应度函数（fitness function）是不是以 'regressmulti' 开头（前12个字符）
% 判断结构体 gp.userdata 中是否不存在字段 bootSampleSize。
% 如果当前使用的适应度函数是以 regressmulti 开头的多基因拟合函数，并且用户没有提供
% bootSampleSize（即 bootstrap 样本数），那么就按默认方式设置它。
if strncmpi(func2str(gp.fitness.fitfun),'regressmulti',12)  && ~isfield(gp.userdata,'bootSampleSize')
    gp.userdata.bootSampleSize = size(gp.userdata.ytrain,1);   
end

%cache init
% 判断是否启用缓存功能（usecache 是一个布尔值）。如果启用，调用 initcache(gp) 来初始化缓存。
if gp.runcontrol.usecache
    gp = initcache(gp);
end

% 当未设置安静模式（即 gp.runcontrol.quiet = false）时，打印本次运行的所有主要参数设置。
if ~gp.runcontrol.quiet
    fns = [];
    % 将所有函数名拼接为一个字符串 fns，用于后续展示。
    for i=1:length(gp.nodes.functions.active_name_UC);
        fns = [fns ' ' gp.nodes.functions.active_name_UC{i}];
    end
    
    if gp.selection.tournament.lex_pressure % 选择压力（是否启用词典排序选择）
        lex_inf = 'True';
    else
        lex_inf = 'False';
    end
    
    disp(' ');
    disp('-------------------------------------------------------------------------');
    disp('GPTIPS 2');
    disp('Symbolic data mining platform for MATLAB');
    disp('Copyright (C) Dominic Searson 2009-2015');
    disp(' ');
    disp('Contact: searson@gmail.com');
    disp(' ');
    
    disp('This program is free software: you can redistribute it and/or modify');
    disp('it under the terms of the GNU General Public License as published by');
    disp('the Free Software Foundation, either version 3 of the License, or');
    disp('(at your option) any later version.');
    disp(' ');
    disp('This program is distributed in the hope that it will be useful,');
    disp('but WITHOUT ANY WARRANTY; without even the implied warranty of');
    disp('MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the');
    disp('GNU General Public License for more details: http://www.gnu.org/licenses');
    disp(' ');
    disp('-------------------------------------------------------------------------- ');
    disp(' ');
    disp('Run parameters');
    disp('--------------');
    disp(['Population size:         ' int2str(gp.runcontrol.pop_size)]);
    disp(['Number of generations:   ' int2str(gp.runcontrol.num_gen)]);
    disp(['Number of runs:          ' int2str(gp.runcontrol.runs)]);
    
    if gp.runcontrol.parallel.auto
        disp('Parallel mode :          auto ');
    elseif gp.runcontrol.parallel.enable
        disp('Parallel mode :          manual ');
    else
        disp('Parallel mode :          off ');
    end
    
    if gp.selection.tournament.p_pareto == 0 % p_pareto = 0：普通锦标赛；> 0，混合 Pareto 锦标赛（多目标导向）
        disp('Tournament type:         regular');
    else
        disp(['Tournament type:         Pareto (probability = ' ...
            num2str(gp.selection.tournament.p_pareto) ')']);
    end
    
    disp(['Tournament size:         ' int2str(gp.selection.tournament.size)]);
    disp(['Elite fraction:          ' num2str(gp.selection.elite_fraction)]); % 保留最好个体的比例
    
    if gp.runcontrol.usecache
        disp('Fitness cache:           enabled');
    else
        disp('Fitness cache:           disabled');
    end
    
    disp(['Lexicographic selection: ' lex_inf]);
    disp(['Max tree depth:          ' int2str(gp.treedef.max_depth)]);
    disp(['Max nodes per tree:      ' int2str(gp.treedef.max_nodes)]);
    disp(['Using function set:     ' fns]);
    disp(['Number of inputs:        ' int2str(gp.nodes.inputs.num_inp)]);
    
    if gp.genes.multigene
        disp(['Max genes:               ' int2str(gp.genes.max_genes)]);
    end
    
    if ~gp.nodes.const.p_ERC % 若 p_ERC = 0：未使用 Ephemeral Random Constants（ERC）
        disp('Using no constants'); % 否则显示允许常数节点取值的范围。
    else
        disp(['Constants range:         [' num2str(gp.nodes.const.range) ']']);
    end
    
    if gp.fitness.complexityMeasure % 复杂度度量方式
        disp('Complexity measure:      expressional'); % 表达式长度相关；
    else
        disp('Complexity measure:      node count');
    end
    
    disp(['Fitness function:        ' func2str(gp.fitness.fitfun) '.m']); % 适应度函数名：regressmulti_fitfun.m
    disp(' ');
end

%parallel computing initialisation
% 调用 gpinitparallel 函数，为后续可能的并行计算（例如多核或集群运算）做准备。
% 目的是提升计算效率，特别是在遗传编程种群较大或迭代次数较多时。
gp = gpinitparallel(gp);

%log run start time
% 记录当前程序运行的开始时间。
% ow 返回当前系统时间（日期时间的数字表示），
% datestr(now,0) 把它转换成字符串格式（如 '26-May-2025 14:30:15'）。
gp.info.startTime = datestr(now,0);

%set elapsed run time count to zero seconds
% 初始化运行时长计数器。给 gp.state.runTimeElapsed 赋值0，表示程序刚开始运行，
% 还没用掉任何时间。后续程序会根据这个变量来累计运行时间，方便监控和超时控制。
gp.state.runTimeElapsed = 0;

function gp=procfuncnodes(gp)
%PROCFUNCNODES Process required function node information prior to a run.
% 对用户配置的 函数节点（Function Nodes） 信息进行预处理和校验，为后续的表达式树生成（如 treegen）和
% 进化操作（如变异、交叉）做好准备。主要包括：
%   检查函数的输入参数个数（Arity）
%   设置激活状态
%   分配唯一标识符（afid）
%   分类函数节点（如零元函数、非零元函数）
%   做一致性和数量限制检查

%loop through function nodes and generate arity list
for i = 1:length(gp.nodes.functions.name)
    
    arity = nargin(gp.nodes.functions.name{i}); % nargin 返回调用函数时传递的输入参数的数量
    
    %some functions have a variable number of input arguments (e.g. rand)
    %In this case generate an error message and exit 
    % 使用 nargin 获取函数接受的输入参数个数（arity）：
    % 1 表示单元函数，如 sin(x)
    % 2 表示二元函数，如 plus(x, y)
    % 如果是变参函数（返回 -1），比如 rand(varargin)，则报错，因为这类函数不适合用于表达式树中的固定节点。
    if arity == -1
        error(['The function ' gp.nodes.functions.name{i} ...
            ' may not be used (directly) as a function node because it has a variable number of arguments.']);
    end
    
    gp.nodes.functions.arity(i) = arity;
end

% 检查 gp.nodes.functions 中是否不存在 'active' 字段；
% 检查 gp.nodes.functions.active 是否为空（如 []、''、未赋值的变量等）。
% 如果未设置 active 字段，则默认所有函数节点都启用。对应于 gp.nodes.functions.name 中的每个函数是否启用。
if ~isfield(gp.nodes.functions,'active') || isempty(gp.nodes.functions.active)
    gp.nodes.functions.active = ones(1,length(gp.nodes.functions.name));
end

% logical() 函数：将输入数据强制转换为逻辑值（true 或 false）
gp.nodes.functions.active = logical(gp.nodes.functions.active);

%check max number of allowed functions not exceeded
% 计算gp.nodes.functions.active 中所有逻辑真值（true）的数量，并将结果赋值给gp.nodes.functions.num_active
gp.nodes.functions.num_active = numel(find(gp.nodes.functions.active));
% GPTIPS 最多支持 22 个激活函数节点，这是因为接下来会为每个函数分配一个单字符 ID。
if gp.nodes.functions.num_active > 22
    error('Maximum number of active functions allowed is 22');
end

%Generate single char Active Function IDentifiers (afid)(a->z excluding
%x,e,i,j) to stand in for function names whilst processing expressions.
%Exclusions are because 'x' is reserved for input nodes, 'e' is used for
%expressing numbers in standard form by Matlab and, by default, 'i' and 'j'
%represent sqrt(-1).
% 生成单个字符的激活函数标识符（afid）（从a到z，排除x、e、i、j），
% 用于在处理表达式时代替函数名称。
% 排除这些字符的原因是：
% - 'x' 被保留用于输入节点，
% - 'e' 在Matlab中用于科学计数法表示数字，
% - 默认情况下，'i' 和 'j' 表示虚数单位（即√-1）。

% 为激活的函数生成唯一的单字母标识符（a-z），同时跳过保留字符 e、i、j、x。
charnum = 96; skip = 0;
for i=1:gp.nodes.functions.num_active
    while true      %e                          %i                    %j                         %x
        if (charnum+i+skip)==101 || (charnum+i+skip)==105 || (charnum+i+skip)==106 || (charnum+i+skip)==120
            skip = skip + 1;
        else
            break
        end
        
    end
    afid(i) = char(charnum+i+skip); % 生成的字母标识符数组，'abcdfghk'
end

%extract upper case active function names for later use
gp.nodes.functions.afid = afid;
% 创建一个大小为 gp.nodes.functions.num_active × 1 的空单元格数组（cell array），
% 并将其赋值给变量 temp
temp = cell(gp.nodes.functions.num_active,1); % 8*1 cell

if numel(gp.nodes.functions.name) ~= numel(gp.nodes.functions.active)
    error('There must be the same number of entries in gp.nodes.functions.name and gp.nodes.functions.active. Check your config file.');
end

% 将 gp.nodes.functions.name 中激活的函数名称（由 gp.nodes.functions.active 逻辑索引筛选）
% 批量赋值给 temp 单元格数组的每个元素。
% 实现多输出分配。
[temp{:}] = deal(gp.nodes.functions.name{gp.nodes.functions.active});
% 提取激活函数名（大写形式）用于输出或比较
[gp.nodes.functions.active_name_UC] = upper(temp);

%generate index locators for arity >0 and arity == 0 active functions. The
%treegen function needs his info later for identifying which functions are
%terminal and which are internal nodes.
% 为参数数量>0（arity>0）和参数数量=0（arity==0）的激活函数生成索引定位器。
% treegen函数后续需要利用这些信息来区分哪些函数是终端节点（terminal），
% 哪些是内部节点（internal nodes）。
active_ar = (gp.nodes.functions.arity(gp.nodes.functions.active)); % [2,2,2,2,1,1,1,1]
fun_argt0 = active_ar > 0; % 1x8 logical 全 1 非零元函数（有输入）=> 内部节点
fun_areq0 =~ fun_argt0; % 1x8 logical 全 0  零元函数（无输入）=> 终端节点

gp.nodes.functions.afid_argt0 = gp.nodes.functions.afid(fun_argt0); %functions with arity > 0 'abcdfghk'
gp.nodes.functions.afid_areq0 = gp.nodes.functions.afid(fun_areq0); %functions with arity == 0 ''
gp.nodes.functions.arity_argt0 = active_ar(fun_argt0);

gp.nodes.functions.fun_lengthargt0 = numel(gp.nodes.functions.afid_argt0);
gp.nodes.functions.fun_lengthareq0 = numel(gp.nodes.functions.afid_areq0);

function gp = initcache(gp)
%INITCACHE Sets up fitness cache.
% Key（键）类型：uint32（无符号 32 位整数）
% Value（值）类型：任意类型（any）
gp.fitness.cache = containers.Map('keytype','uint32','valuetype','any');

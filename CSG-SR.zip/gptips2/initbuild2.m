function gp=initbuild2(gp,causalGraph)
%INITBUILD Generate an initial population of GP individuals.
%
%   GP = INITBUILD(GP) creates an initial population using the parameters
%   in the structure GP. Various changes to fields of GP are made.
%
%   Remarks:
%
%   Each individual in the population can contain 1 or more separate trees
%   (if more than 1 then each tree is referred to as a gene of the
%   individual). This is set by the user in the config file in the field
%   GP.GENES.MULTIGENE.
%
%   Each individual is a cell array. You can use cell addressing to
%   retrieve the individual genes. E.g. GP.POP{3}{2} will return the 2nd
%   gene in the third individual.
%
%   Trees are (by default) constructed using a probabilistic version of
%   Koza's ramped 1/2 and 1/2 method. E.g. if maximum tree depth is 5 and
%   population is 100 then, on average, 20 will be generated at each depth
%   (1/2 using 'grow' and 1/2 using 'full').
%
%   Multiple copies of genes in an individual are disallowed when
%   individuals are created. There is, however, no such restriction imposed
%   on future generations.
%
%   (c) Dominic Searson 2009-2015
%
%   GPTIPS 2
%
%   See also POPBUILD, TREEGEN

% Extract temp variables from the gp structure
popSize = gp.runcontrol.pop_size;
maxNodes = gp.treedef.max_nodes;
maxGenes = gp.genes.max_genes;

%override any gene settings if using single gene gp
if ~gp.genes.multigene
    maxGenes = 1;
end

%initialise vars
gp.pop = cell(popSize,1);
numGenes = 1;


% 加载因果路径（只需加载一次）
currentScriptPath = fileparts(mfilename('fullpath'));
parentPath = fileparts(currentScriptPath);
resourcePath = fullfile(parentPath, 'resource', causalGraph);
causalData = load(resourcePath);
causal_path = causalData.causal_path;

totalVars = size(gp.userdata.xtrain, 2);

% 展平所有子 cell
allVars = [causal_path{:}];    % 1×(4*3) cell
% 去除所有 'y'
allVars(strcmp(allVars, 'y')) = [];  
% 去重，得到不含 'y' 的变量列表
uniqueVars = unique(allVars);  % {'x1','x2','x4','x5'}

%building process
for i=1:popSize %loop through population
    
    %randomly pick num of genes in individual
    if maxGenes > 1
        % numGenes = ceil(rand*maxGenes);
        % 将其设置为2棵树，第一棵树为因果树，第二棵为非因果树。
        numGenes = gp.genes.max_genes; 
    end
    
    individ = cell(1,(numGenes)); %construct empty individual
    
    checkConstraint = false;  % 初始不检查约束
    for z = 1:numGenes %loop through genes in each individual and generate a tree for each
        
        %generate gene z and check that genes 1...z-1 are different
        geneLoopCounter = 0;
        while true
            
            geneLoopCounter = geneLoopCounter + 1;
            
            %generate a trial tree for gene z
            temp = treegen(gp);
            numnodes = getnumnodes(temp);
            
            if numnodes <= maxNodes
                
                copyDetected = false;
                
                % 第一棵树是因果树,对其进行构建
                if z == 1
                    % 从字符串temp中提取变量名x?
                    pat = 'x(\d+)';
                    matches = regexp(temp, pat, 'match');  % matches是cell array，比如 {'x7', 'x3', 'x6'}
                    
                    % 去重，只保留唯一变量名
                    matches = unique(matches);

                    % 一旦满足条件，就启用约束检查
                    if ~checkConstraint
                        if numel(uniqueVars) >= round(totalVars / 3) && numel(causal_path) >= round(totalVars / 3)
                            checkConstraint = true;
                        else
                            break;  % 不满足触发条件，默认接受
                        end
                    end

                    % 如果进入约束模式，则每次都检查
                    if checkConstraint
                        if satisfies_constraint(matches, causal_path)
                            break;  % 满足约束，接受
                        else
                            continue;  % 不满足，重新生成
                        end
                    end
                end
               
               
                % 只有当当前是第二个基因或更后面的位置时，才需要检查是否有重复。
                if z > 1 %check previous genes for copies
                    
                    for j = 1:z-1;
                        % 如果当前基因 temp 与已有的第 j 个基因完全一致，则表示有重复。
                        if strcmp(temp,individ{1,j})
                            copyDetected = true;
                            break
                        end
                    end
                    
                end
                
                if ~copyDetected
                    break
                end
                
            end %max nodes check
            
            %display a warning if having difficulty building trees due to
            %constraints
%             if ~gp.runcontrol.quiet && geneLoopCounter > 10
%                 disp('initbuild: iterating tree build loop because of uniqueness constraints.');
%             end
            
        end %while loop
        
        individ{1,z} = temp;
        
    end %gene loop
    
    %write new individual to population cell array
    gp.pop{i,1} = individ;
end

end

% 判断函数实现
function is_valid = satisfies_constraint(var_set, causal_path)
% 判断是否存在 causal_path 中若干路径的组合，其前置变量并集完全覆盖 var_set（忽略y）
% var_set：当前符号表达式中用到的所有变量。
% causal_path：所有合法的因果路径集合。每条路径是一个cell，最后一个y表示目标变量，前面变量是这条路径的输入。

% 边界情况检查
% 如果var_set中变量太少（只有一个或者更少），直接返回false
r = length(var_set);
if r <= 1
    is_valid = false;
    return;
end

% 遍历路径组合数目
n = length(causal_path); % 4，一共有多少条因果路径
is_valid = false;

 % 遍历 1~max_chains 条路径的所有组合
for k = 1:r
    if k > n
        break;
    end

    idx_combs = nchoosek(1:n, k); % 从n条路径中不重复选k条组合
    num_combs = size(idx_combs, 1); % 计算idx_combs行数，有多少组组合

    for comb_idx = 1:num_combs % 合并组合中所有路径的“输入变量”
        union_vars = {};

        for j = 1:k
            idx = idx_combs(comb_idx, j);
            path_vars = causal_path{idx};

            % 去除最后一个元素（通常是目标变量 y）
            if iscell(path_vars)
                inputs = path_vars(1:end-1);
                union_vars = [union_vars, inputs{:}];
            else
                union_vars = [union_vars, path_vars];  % 防止异常结构
            end
        end

        union_vars = unique(union_vars);
        % 判断 union_vars 是否“恰好覆盖” var_set
        % length(union_vars) == r → 数量匹配
        % ismember(var_set, union_vars) → 每个变量都在里面
        if length(union_vars) == r && all(ismember(var_set, union_vars))
            is_valid = true;
            return;
        end
    end
end
end

function decodedArray = tree2evalstr(encodedArray,gp)
%TREE2EVALSTR Converts encoded tree expressions into math expressions that MATLAB can evaluate directly.
%
%   DECODEDARRAY = TREE2EVALSTR(ENCODEDARRAY,GP) processes the encoded
%   symbolic expressions in the cell array ENCODEDARRAY using the
%   information in the GP data structure and creates a cell array
%   DECODEDARRAY, each element of which is an evaluable Matlab string
%   expression.
%   DECODEDARRAY = TREE2EVALSTR(ENCODEDARRAY, GP) 这个函数会把 ENCODEDARRAY 中的符号
%   表达式（是编码过的形式）转换成可以在 MATLAB 中直接运行的字符串表达式，转换过程中
%   会用到 GP 结构体里的配置信息。最终结果是一个新的单元格数组 DECODEDARRAY，里面的每
%   个元素都是可执行的表达式字符串。

%   Remarks: 
%
%   GPTIPS uses a encoded string representation of expressions which is not
%   very human readable, but is fairly compact and makes events like
%   crossover and mutation easier to handle. An example of such an
%   expression is a(b(x1,a(x4,x3)),c(x2,x1)). Before an expression can be
%   evaluated it is converted using TREE2EVALSTR to produce an evaluable
%   math expression, e.g. times(minus(x1,times(x4,x3)),plus(x2,x1)).
%   GPTIPS 使用一种编码后的字符串来表示表达式，这种表示方式对人类来说不太易读，但相对紧凑，
%   并且更容易处理诸如交叉和变异等操作。
%   例如这样的表达式：a(b(x1,a(x4,x3)),c(x2,x1))。
%   在表达式可以被求值之前，会通过 TREE2EVALSTR 函数转换为可执行的数学表达式，例如：
%   times(minus(x1,times(x4,x3)),plus(x2,x1))。
%
%   Copyright (c) 2009-2015 Dominic Searson 
%
%   GPTIPS 2
%
%   See also EVALFITNESS, TREEGEN, GPREFORMAT（参见：EVALFITNESS, TREEGEN, GPREFORMAT）

%loop through active function list and replace with function names
%   将基因表达式中用来代表函数的内部编码（标识符）替换成对应的可读函数名称，
%   并将最终结果转换成小写字母形式。
for j=1:gp.nodes.functions.num_active % 遍历当前活动函数集中的所有函数
    % strrep：将字符串中的特定子串替换为另一个子串。
    % newStr = strrep(originalStr, oldSubstr, newSubstr); ->{'EXP(TIMES(EXP(x4),[5.0485]))'}
    encodedArray = strrep(encodedArray,gp.nodes.functions.afid(j),gp.nodes.functions.active_name_UC{j});
end

decodedArray = lower(encodedArray); % 小写形式：{'exp(times(exp(x4),[5.0485]))'}
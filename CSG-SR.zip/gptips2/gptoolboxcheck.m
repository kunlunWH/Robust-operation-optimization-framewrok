function [symbolicResult, parallelResult, statsResult] = gptoolboxcheck
%GPTOOLBOXCHECK Checks if certain toolboxes are installed and licensed.
%   检查MATLAB是否安装并授权了以下三个工具箱：
%           Symbolic Math Toolbox（符号数学工具箱）；
%           Parallel Computing Toolbox（并行计算工具箱）；
%           Statistics Toolbox（统计工具箱）或其新名称 Statistics and Machine Learning Toolbox
%   Checks for the Stats, Parallel Computing and Symbolic Math toolboxes. 
%   
%   输出三个布尔值：1
%   Copyright (c) 2009-2015 Dominic Searson
%
%   GPTIPS 2
%
%   See also GPINIT

v = ver;
[toolboxes{1:length(v)}] = deal(v.Name);
symbolicResult = ismember('Symbolic Math Toolbox',toolboxes) && license('test','symbolic_toolbox');
parallelResult = ismember('Parallel Computing Toolbox',toolboxes) && license('test','distrib_computing_toolbox');
statsResult = ( ismember('Statistics Toolbox',toolboxes) || ismember('Statistics and Machine Learning Toolbox',toolboxes) ) ...
    && license('test','statistics_toolbox'); 


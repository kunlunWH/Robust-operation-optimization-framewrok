function gp = gptoc(gp)
%GPTOC Updates the running time of this run.
%   更新遗传编程（GP）运行的总耗时
%
%   GP = GPTOC(GP) updates the running time for the current run. 
%
%   Copyright (c) 2014 Dominic Searson 
%
%   GPTIPS 2
%
%   See also GPTIC

% 把这一次的耗时 toc(gp.state.tic) 加到累计总耗时 gp.state.runTimeElapsed 上。
% gp.state.tic：是之前记录的某一段时间的起点，保存了某一代、某一步骤开始的时间点。
% toc(gp.state.tic)：从 tic 开始到现在，过去了多少秒。
% gp.state.runTimeElapsed：这是一个字段，用来累计整个进化过程已经花费的总时间（单位秒）
gp.state.runTimeElapsed = gp.state.runTimeElapsed + toc(gp.state.tic);


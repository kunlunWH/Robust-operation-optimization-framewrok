function gp = gp_userfcn(gp)
%GP_USERFCN Calls a user defined function once per generation if one has been specified in the field GP.USERDATA.USER_FCN.
%   GP_USERFCN 调用用户定义的函数，每一代调用一次（如果在字段 GP.USERDATA.USER_FCN 中指定了该函数）。
%   Remarks:
%
%   The user defined function must accept (as 1st) and return (as 2nd) the
%   GP structure as arguments.
%
%   Example:
%
%   In multigene symbolic regression the function
%   regressmulti_fitfun_validate can be called once per generation to
%   evaluate the best individual so far on a validation ('holdout') data
%   set.
%   在多基因符号回归中，函数 regressmulti_fitfun_validate 可以在每一代中调用一次，
%   用于在验证集（“保留”数据集）上评估当前为止表现最好的个体。
%
%   Copyright (c) 2009-2015 Dominic Searson 
%
%   GPTIPS 2

if ~isempty(gp.userdata.user_fcn)
    [~,gp] = feval(gp.userdata.user_fcn,gp);
end

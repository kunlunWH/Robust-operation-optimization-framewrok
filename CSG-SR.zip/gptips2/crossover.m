function [son,daughter] = crossover(mum,dad,gp)
%CROSSOVER Sub-tree crossover of encoded tree expressions to produce 2 new ones.
%
%   [SON,DAUGHTER] = CROSSOVER(MUM,DAD,GP) uses standard subtree crossover
%   on the expressions MUM and DAD to produce the offspring expressions SON
%   and DAUGHTER.
%
%   Copyright (c) 2009-2015 Dominic Searson 
%
%   GPTIPS 2
%
%   See also MUTATE

% 典型的表达式树交叉替换操作，在符号回归或遗传编程中用于生成新个体
%select random crossover nodes in mum and dad expressions（在母体和父体表达式中随机选择交叉节点）
% picknode是 GPTIPS 中的一个函数，用于随机选择表达式中的某个节点（子树）的位置索引；
m_position = picknode(mum,0,gp); % 提取交叉点，子树的位置：1,(mum:'h(x2)')，表示整个表达式
d_position = picknode(dad,0,gp); % 3,(dad:'c(x2,[-3.5018])')，表示子树‘x2’。

%extract main and subtree expressions
% sub：在 position 处对应的子树（可理解为待交叉的部分）
% main：把该子树替换为占位符 $ 的主干表达式（用于未来替换）。
% 占位符 $ 是进行字符串替换操作的桥梁
% son = strrep('c($,[-3.5018])', '$', 'h(x2)') = 'c(h(x2),[-3.5018])'
% 把 dad 的表达式中选中位置（'x2'）用 'h(x2)' 替换；
% 得到 son = 'c(h(x2),[-3.5018])'。
[m_main,m_sub] = extract(m_position,mum); % m_main:'$';m_sub:'h(x2)'
[d_main,d_sub] = extract(d_position,dad); % d_main:'c($,[-3.5018])'; d_sub:'x2'

% 执行交叉替换，生成后代
%combine to form 2 new GP trees
% strrep(A, B, C)：表示在字符串 A 中，将所有子字符串 B 替换为 C，返回结果。
daughter = strrep(m_main,'$',d_sub); % x2
son = strrep(d_main,'$',m_sub); % c(h(x2),[-3.5018])
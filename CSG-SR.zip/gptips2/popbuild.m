function gp = popbuild(gp)
%POPBUILD Build next population of individuals.
%
%   GP = POPBUILD(GP) uses the current population (stored in GP.POP) and
%   their fitnesses (stored in GP.FITNESS.VALUES) and, optionally,
%   complexities to create the next generation of individuals.
%   GP = POPBUILD(GP) 使用当前种群（存储在 GP.POP 中）及其适应度
%   （存储在 GP.FITNESS.VALUES 中），并且可选地使用复杂度信息，来创建下一代个体。
%
%   Copyright (c) 2009-2015 Dominic Searson
%
%   GPTIPS 2
%
%   See also INITBUILD

% initialise new population （创建一个大小为种群规模的 cell 数组 newPop，用于存储新生成的个体。）
newPop = cell(gp.runcontrol.pop_size,1); % 100x1 cell

%the number of new members to be constructed after elitism is accounted for
% 新种群中个体由当代精英个体+交叉变异操作生成的新个体构成。
% 除了精英外，需要构建的新个体数
num2build = floor( (1 - gp.selection.elite_fraction) * gp.runcontrol.pop_size); 
num2skim = gp.runcontrol.pop_size - num2build; % 精英个体数，最后直接放入新种群。

%parameter shortcuts
p_mutate = gp.operators.mutation.p_mutate; % 0.14，突变概率
p_direct = gp.operators.directrepro.p_direct; % 0.02，直接复制概率
maxDepth = gp.treedef.max_depth; % 10，最大树深度
max_nodes = gp.treedef.max_nodes; % Inf，最大节点数
p_cross_hi = gp.genes.operators.p_cross_hi; % 0.2
crossRate = gp.genes.operators.hi_cross_rate; % 0.5
useMultiGene = gp.genes.multigene; % 是否采用多基因个体（不采用）
pmd = p_mutate + p_direct; % 0.16
maxNodesInf = isinf(max_nodes); % 1（判断 x 中的元素是否是无穷大）
maxGenes = gp.genes.max_genes; % 4

%reset cache（如果启用了缓存，清空上一代缓存数据。）
if gp.runcontrol.usecache
    remove(gp.fitness.cache,gp.fitness.cache.keys);
end

%update gen counter （代计数器加1，记录遗传算法迭代次数）
gp.state.count = gp.state.count + 1;

buildCount = 0;

% （循环执行，直到构建出所需数量的新个体为止）
%loop until the required number of new individuals has been built. 
while buildCount < num2build;
    
    buildCount = buildCount + 1;
    
    %probabilistically select a genetic operator（以概率方式选择一个遗传算子）
    p_gen = rand;
    
    if p_gen < p_mutate  %select mutation
        eventType = 1;
    elseif p_gen < pmd   %direct reproduction
        eventType = 2;
    else                 %crossover
        eventType = 3;
    end
    
    
    % mutation (first select a individual, then a gene, then do ordinary mutate)
    if eventType == 1
        
        parentIndex = selection(gp);  % pick the population index of a parent individual using selection operator
        parent = gp.pop{parentIndex}; % 从种群中提取这个个体
        
        if useMultiGene % if using multigene, extract a target gene
            numParentGenes = numel(parent);
            targetGeneIndex = ceil(rand * numParentGenes); %randomly select a gene from parent
            targetGene = parent{1,targetGeneIndex}; % extract it
        else % 单基因情况下，为整个表达式树
            targetGeneIndex = 1;
            targetGene = parent{1};
        end
        
        mutateSuccess = false;
        for loop = 1:10	%loop until a successful mutation occurs (max loops=10) 最多尝试10次
            
            % 'b(x2,a(f(x1),x1))'->'b(x2,a(f(b(k(c(x4,x1)),a(b(x1,[0.7123]),b(x4,x1)))),x1))'
            mutatedGene = mutate(targetGene,gp); 
            mutatedGeneDepth = getdepth(mutatedGene); % 7
            % 深度约束判断
            if mutatedGeneDepth <= maxDepth 
                
                if maxNodesInf % 如果节点数无限制，则成功
                    mutateSuccess = true;
                    break;
                end
                
                mutatedGeneNodes = getnumnodes(mutatedGene);
                if mutatedGeneNodes <= max_nodes
                    mutateSuccess = true;
                    break;
                end
            end %end of constraint check
            
        end  %end of mutate for loop
        % 如果所有变异（10次）尝试都失败，保留原始个体
        %if no success then use parent gene
        if ~mutateSuccess
            mutatedGene = targetGene;
        end
        
        %add the mutated individual to new pop
        parent{1,targetGeneIndex} = mutatedGene; % 将原个体中的某个基因替换为变异结果
        newPop{buildCount,1} = parent; % 加入新种群
        
        %direct reproduction operator
    elseif eventType == 2
        
        parentIndex = selection(gp);  % pick a parent(从当前种群中选取出对应个体parent)
        parent = gp.pop{parentIndex}; % 单基因结构x1
        
        % copy to new population 将该个体原样复制到新种群newPop中的第buildCount个位置
        newPop{buildCount} = parent; % 直接传承
        
        % store fitness etc of copied individual if cache enabled
        if gp.runcontrol.usecache 
            cachedData.complexity = gp.fitness.complexity(parentIndex,1);
            cachedData.returnvalues = gp.fitness.returnvalues{parentIndex,1};
            cachedData.value = gp.fitness.values(parentIndex,1);
            gp.fitness.cache(buildCount) = cachedData;
        end
        
        %crossover operator - can either pick 'high level' crossover
        %(crosses over entire genes with no tree alteration) or 'low level'
        % which crosses over individual genes at the tree level.
        % 交叉算子 —— 可以选择“高层次”交叉（直接交换整个基因，不改变树结构），
        % 或“低层次”交叉（在树结构层面对单个基因进行交叉）。
    elseif eventType == 3
        
        highLevelCross = false;
        
        if useMultiGene
            
            %select crossover type if multigene enabled
            if rand < p_cross_hi
                highLevelCross = true;
            end
            
        end
        
        %Select Parents （选择两个父个体）
        parentIndex = selection(gp); % 10
        dad = gp.pop{parentIndex}; % 1x1 cell，{'c(x2,[-3.5018])'}
        numDadGenes = numel(dad); % 1
        
        parentIndex = selection(gp);
        mum = gp.pop{parentIndex}; % {'h(x2)'}
        numMumGenes = numel(mum); % 1
        
        if highLevelCross % 高层交叉: 交换多个基因的集合
            if numMumGenes>1 || numDadGenes>1
                %high level crossover (only use if either parent has more
                %than one gene) This is modified/simplified from the
                %version in GPTIPS v1. This version just chooses between 1
                %and N genes to exchange randomly and independently for
                %each parent with a probability set by
                %gp.genes.operators.hi_cross_rate (where N =  number of
                %genes in that individual). Like GPTIPS 1, this assumes
                %that the order of genes within an individual is not
                %important. 
                
                dadGeneSelectionInds = rand(1,numDadGenes) < crossRate;
                mumGeneSelectionInds = rand(1,numMumGenes) < crossRate;
                
                if ~any(dadGeneSelectionInds)
                    dadGeneSelectionInds(1,ceil(numDadGenes *rand)) = true;
                end
                
                if ~any(mumGeneSelectionInds)
                    mumGeneSelectionInds(1,ceil(numMumGenes *rand)) = true;
                end
                
                dadSelectedGenes = dad(dadGeneSelectionInds);
                mumSelectedGenes = mum(mumGeneSelectionInds);
                
                dadRemainingGenes = dad(~dadGeneSelectionInds);
                mumRemainingGenes = mum(~mumGeneSelectionInds);
                
                mumOffspring = [mumRemainingGenes dadSelectedGenes];
                dadOffspring = [dadRemainingGenes mumSelectedGenes];
                
                %curtail offspring longer than the max allowed number of genes
                %before writing to new population (only write 1 if no space for 2 offspring)
                newPop{buildCount,1} = mumOffspring(1:(min(end,maxGenes)));
                buildCount = buildCount+1;
                
                if buildCount <= num2build
                    newPop{buildCount,1} = dadOffspring(1:(min(end,maxGenes)));
                end
                
            else
                highLevelCross = false;
            end
        end
        
        % 低层交叉: 随机选择父母各一个基因，交换子树。它发生在基因内部，也就是在表达式树结构内部进行交叉重组。
        %low level crossover: picks a random gene from each parent and
        %crosses them. The offspring replace the original target genes
        if ~highLevelCross
            
            if useMultiGene %if multigene then select target genes
                dad_target_gene_num = ceil(rand*numDadGenes); %randomly select a gene from dad
                mum_target_gene_num = ceil(rand*numMumGenes); %randomly select a gene from mum
                dad_target_gene = dad{1,dad_target_gene_num};
                mum_target_gene = mum{1,mum_target_gene_num};
            else % 若是单基因个体，则只存在一个基因，直接选用第一个。
                dad_target_gene_num = 1;
                mum_target_gene_num = 1;
                dad_target_gene = dad{1}; % {'c(x2,[-3.5018])'}
                mum_target_gene = mum{1}; % {'h(x2)'}
            end
            
            % 最多尝试 10 次 crossover，直到 offspring 满足结构约束。
            for loop = 1:10  %loop (max 10 times) until both children meet size constraints（循环（最多 10 次），直到两个子代都满足大小约束条件。）
                
                %produce 2 offspring
                [son,daughter] = crossover(mum_target_gene,dad_target_gene,gp);
                son_depth = getdepth(son); % 'b(x2,x2)'，2
                
                % 检查两个子代是否同时满足大小和深度的约束条件。如果满足，则跳出 while 循环并继续执行后续操作。
                %check if both children meet size and depth constraints，if true then break out of while loop and proceed
                crossOverSuccess = false;
                if son_depth <= maxDepth
                    daughter_depth = getdepth(daughter);
                    if daughter_depth <= maxDepth
                        
                        if maxNodesInf % 若允许节点数无限制，则直接成功
                            crossOverSuccess = true;
                            break;
                        end
                        
                        son_nodes = getnumnodes(son);
                        if son_nodes <= max_nodes
                            daughter_nodes = getnumnodes(daughter);
                            if  daughter_nodes <= max_nodes
                                crossOverSuccess = true;
                                break;
                            end;
                        end
                    end
                end
                
            end
            
            %if no success then re-insert parents ( 10 次尝试都失败,若失败则保留原父母基因)
            if ~crossOverSuccess
                son = dad_target_gene;
                daughter = mum_target_gene;
            end
            % 将子代写回父代的对应基因位置，并写入种群中
            %write offspring back to right gene positions in parents and write to population
            dad{1,dad_target_gene_num} = son;
            newPop{buildCount} = dad;
            
            buildCount = buildCount+1;
            
            if buildCount <= num2build
                mum{1,mum_target_gene_num} = daughter;
                newPop{buildCount} = mum;
            end
            
        end %end of if ~use_high
        
    end % end of op_type if
    
end %end of ii-->num2build  for


%skim off the existing elite individuals and stick them on the end of the
%new population. When sorting there may be many individuals with the same
%fitness. However, some of these have fewer nodes/lower complexity than
%others, so skim off the first one as the existing member with the fewest
%nodes. This should exert a degree of parsimony pressure.
% 从现有种群中筛选出精英个体，并将它们放到新种群的末尾。在排序时，可能会有许多个体拥有
% 相同的适应度值。然而，这些个体中有些节点数更少、复杂度更低，因此筛选出节点数最少的那
% 个作为现有成员。这种做法可以对模型施加一定的简约性压力（即偏好更简单的模型）。

% get indices of best num2skim individuals（对适应度值进行排序，默认是从小到大排序）
[~,sortIndex] = sort(gp.fitness.values); % sortIndex：100x1 double

% if maximising need to flip vectors
% （如果问题是最大化适应度（不是最小化），则需要将排序结果倒置，即把适应度最高的个体排到前面。）
if ~gp.fitness.minimisation % 这里gp.fitness.minimisation=1，即最小化问题
    sortIndex = flipud(sortIndex); % flipud就是上下翻转向量，使索引按适应度从高到低排列。
end

% 循环选出要保留的精英个体的索引，从最优个体开始，选出num2skim个
for g = 1:num2skim % 15
    
    oldIndex = sortIndex(g);
    
    % for the first individual to skim off, pick the 'best' member with the
    % lowest complexity
    % 对第一个精英个体特殊处理，找出所有适应度与当前最优个体相同的个体bestInds，
    % 从这些个体中，根据复杂度排序，选择出复杂度最低的（偏简单的模型）
    if g == 1
        bestInds = find( gp.fitness.values == gp.fitness.values(oldIndex) );
        [~,oldIndex] = sort(gp.fitness.complexity(bestInds));
        oldIndex = bestInds(oldIndex(1)); %if more than one with same complexity just pick the first
    end
    
    % 计算新种群中存放这些精英个体的位置，它放在新种群的后面。
    newIndex = num2build + g;
    % 从当前种群复制对应的个体
    copiedIndividual = gp.pop{oldIndex,1};
    
    % cache fitness, complexity etc.
    % 如果启用了缓存，直接将精英个体的适应度和复杂度等信息缓存，避免重复计算。
    if gp.runcontrol.usecache
        cachedData.complexity = gp.fitness.complexity(oldIndex,1);
        cachedData.returnvalues = gp.fitness.returnvalues{oldIndex,1};
        cachedData.value = gp.fitness.values(oldIndex,1);
        gp.fitness.cache(newIndex) = cachedData;
    end
    
    % 把精英个体放到新种群的对应位置
    newPop{newIndex,1} = copiedIndividual;
    
end

gp.pop = newPop;